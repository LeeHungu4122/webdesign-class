$(document).ready(function () {
    $(".menu ul li").on("mouseover", function () {
        $('.sub').stop().slideDown();
        $('.bg').stop().slideDown();
    });

    $(".menu ul li").on("mouseleave", function () {
        $('.sub').stop().slideUp();
        $('.bg').stop().slideUp();
    });

});
