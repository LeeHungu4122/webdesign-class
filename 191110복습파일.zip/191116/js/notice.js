$(document).ready(function () {

    $("#tab > div > .dt > a").on("click", function (e) {
        e.preventDefault();

        $("#tab > div > .dt").removeClass("on");
        $("#tab > div > .dd").removeClass("on");

        $(this).parent(".dt").addClass("on");
        $(this).parent(".dt").next(".dd").addClass("on");
    });

});
