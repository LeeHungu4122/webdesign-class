$(document).ready(function () {
    /* 풀다운 */
    
    $(".menu > li").on("mouseover", function () {
        $(this).children(".sub").stop().slideDown();
    });

    $(".menu > li").on("mouseleave", function () {
        $(this).children(".sub").stop().slideUp();
    });
    
    /* 슬라이더 */
    
    start();
    
    var imgs = 2;
    var now = 0;
    
    function start() {
        $(".visual > img").eq(0).siblings().css("opacity", 0)
        setInterval(function() {
           slide(); 
        }, 3000);
    }
    
    function slide() {
        now = now == imgs ? 0 : now += 1;
        
        $(".visual > img").eq(now - 1).css("opacity", 0)
        $(".visual > img").eq(now).css("opacity", 1)    
    }
});
