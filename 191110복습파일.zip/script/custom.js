$(document).ready(function(){
    
    //gnb 폴다운
    $('.menu ul li').on('mouseover',function(){
       $('.sub').stop().slideDown();
       $('.bg').stop().slideDown();
    });
    
    $('.menu ul li').on('mouseleave',function(){
       $('.sub').stop().slideUp();
       $('.bg').stop().slideUp();
    });
    
    //슬라이더
    start();
    
    var imgs = 2;
    var now = 0;
    
    
    function start(){
        $('.visual>img').eq(0).siblings().css('opacity','0')
        setInterval(function(){slide()},3000);
    }
    
    function slide(){
        
        now = now==imgs ? 0 : now+=1;
        
        $('.visual>img').eq(now-1).css('opacity','0')
        $('.visual>img').eq(now).css('opacity','1')
    }
    
    
    //팝업창
    $('.click').on('click', function(){
       $('.popUp').show(); 
    });
    
    $('.btn').on('click', function(){
       $('.popUp').hide(); 
    });
 
    
    
});









