$(document).ready(function () {
    $(".menu > li").on("mouseover", function () {
        $(this).children(".sub").stop().slideDown();
    });

    $(".menu > li").on("mouseleave", function () {
        $(this).children(".sub").stop().slideUp();
    });
    
    start();
    
    var imgs = 2;
    var now = 0;
    
    function start() {
        $(".visual > img").eq(0).siblings().css("margin-left", '-100%')
        setInterval(function(){
           slide()
        }, 3000)
    }
    
    function slide() {
        now = now == imgs ? 0 : now =+ 1;
        
        $(".visual > img").eq(now - 1).css("margin-left", '-100%')
        $(".visual > img").eq(now).css("margin-left", '0%')
    }
    
    $('.visual > h2').css('margin-left', 0);
    
    $(".click").on("click", function() {
       $(".popup").show(); 
    });
    
    $(".btn").on("click", function() {
       $(".popup").hide(); 
    });
});
